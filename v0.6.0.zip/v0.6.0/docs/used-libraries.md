# Libraries Used

## 1. [SweetAlert2](https://sweetalert2.github.io/)
Used for beautiful alert dialogs.
