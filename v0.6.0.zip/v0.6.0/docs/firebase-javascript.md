Copy and paste these scripts into the bottom of your <body> tag, but before you use any Firebase services:

```html

<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyAZ4Kxk-oT3K7MO9jj9m6ea2lpVTBArJIU",
    authDomain: "m-quiz-game.firebaseapp.com",
    projectId: "m-quiz-game",
    storageBucket: "m-quiz-game.firebasestorage.app",
    messagingSenderId: "584505249855",
    appId: "1:584505249855:web:4eae9a1fd4b71aeec6e88a"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
</script>

```